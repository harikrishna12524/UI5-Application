sap.ui.define([],function(){
    return {
        statusLeaveText: function(sStatus){
            if(sStatus=="R"){
                return "Rejected"
            }else if(sStatus == "W"){
                return "Waiting"
            }else{
                return "Accepted"
            }
        },

        statusLeaveColor:function(sStatus){
            if(sStatus=="R"){
                return "Error"
            }else if(sStatus == "W"){
                return "Warning"
            }else{
                return "Success"
            }
        },

        typeText:function(type){
            if(type=="S"){
                return "Sick"
            }else{
                return "Casual"
            }
        },

        acceptButtonEnabled:function(sStatus){
            if(sStatus=="A"){
                return false;
            }
            return true;
        },

        rejectButtonEnabled:function(sStatus){
            if(sStatus=="R"){
                return false;
            }
            return true;
        }
    }
})