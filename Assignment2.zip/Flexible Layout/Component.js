sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/f/library"
], function (UIComponent, JSONModel, fioriLibrary) {
	"use strict";

	return UIComponent.extend("Harikrishna.Component", {

		metadata: {
			manifest: "json"
		},

		init: function () {
			// call the init function of the parent
			UIComponent.prototype.init.apply(this, arguments);

			this.setModel(new JSONModel(), "layout");
			this.oModel = this.getModel("layout");

			// create the views based on the url/hash
			this.oRouter = this.getRouter();
			this.oRouter.attachBeforeRouteMatched(this._manageLayout, this);
			this.oRouter.initialize();
		},

		_manageLayout: function(oEvent){
			let currentlayout = oEvent.getParameters().arguments.layout;
			let leaveObj = oEvent.getParameters().arguments.oLeave;
			if(!currentlayout){
				currentlayout = fioriLibrary.LayoutType.OneColumn
			}
			
			this.oModel.setProperty("/layout", currentlayout);

		}

	});

});
