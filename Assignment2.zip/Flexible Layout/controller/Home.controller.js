sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/f/library"
], function(Controller, fioriLibrary){
    return Controller.extend("Harikrishna.controller.Home",{

        onNavToLeaveRegistry: function(oEvent){
            this.getOwnerComponent().getRouter().navTo(
                "leaveDataSheet", {
                    layout: fioriLibrary.LayoutType.OneColumn,
                    oLeave: window.encodeURIComponent(oEvent.getSource().getText())
                }
            );
        }
    })
})