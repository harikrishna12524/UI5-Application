sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/f/library",
    "../model/formatter"
], function(Controller, JSONModel, fioriLibrary, formatter){
    return Controller.extend("Harikrishna.controller.LeaveDetail",{
        formatter:formatter,
        onInit: function(){
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.getRoute("leaveDataSheet").attachPatternMatched(this._onObjectMatched, this);
        },

        _onObjectMatched: function(oEvent){
            this.getView().bindElement({
                path: "/" + window.decodeURIComponent(oEvent.getParameter("arguments").oLeave),
                model: "leaves"
            })
        },

        onStatusChange: function(oEvent){
            let newStat = oEvent.getSource().getType()=="Accept"?"A":"R";
            this.getOwnerComponent().getModel("leaves").setProperty(this.getView().getBindingContext("leaves").getPath()+"/status", newStat)
            // debugger;
        },

        onNavBack:function(oEvent){
            this.getOwnerComponent().getRouter().navTo(
                "leaveDataSheet", {
                    layout: fioriLibrary.LayoutType.OneColumn,
                    oLeave: window.encodeURIComponent("/")
                }
            );
        },

        onDebug: function(){
            debugger;
        }
    })
})