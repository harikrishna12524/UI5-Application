sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/f/library",
    "../model/formatter"
], function(Controller, JSONModel, fioriLibrary, formatter){
    return Controller.extend("Harikrishna.controller.Leave",{
        formatter:formatter,

        
        onInit: function(){
            let aLeaves = [];
            let aEmployees = this.getOwnerComponent().getModel("employeeData").getProperty("/employeeData");
            for(employee of aEmployees){
                for(leave of employee.Leaves){
                    leave.employee = employee;
                    aLeaves.push(leave);
                }
            }
            this.getOwnerComponent().setModel(new JSONModel(aLeaves), "leaves");
        },

        onLeaveClick: function(oEvent){
            this.getOwnerComponent().getRouter().navTo(
                "leaveDataSheet", {
                    layout: fioriLibrary.LayoutType.TwoColumnsMidExpanded,
                    oLeave: window.encodeURIComponent(oEvent.getSource().getBindingContextPath("leaves").substr(1))
                }
            );
        },

        onDebug: function(){
            debugger;
        }


    })
})