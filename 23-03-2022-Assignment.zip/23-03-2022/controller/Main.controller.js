sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast"
],function(Controller, JSONModel, MessageToast){
    return Controller.extend("app.controller.Main",{
        onInit: function(){
            
        },

        onDug: function(){
            debugger;
        },

        onNavToCart: function(){
            let router = this.getOwnerComponent().getRouter();
            router.navTo("cart");
        },

        onAddToCart: function(oEvent){
            let item = oEvent.getSource().data("prodId");
            let cartModel = sap.ui.getCore().getModel("cartData").getProperty("/cartItem");
            if(cartModel[item]){
                cartModel[item]++;
            }else{
                cartModel[item] = 1;
            }
        }

        
    })
})