sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
], function(Controller, JSONModel){
    return Controller.extend("app.controller.Cart",{
        onInit:  function(){
            var cartItem = sap.ui.getCore().getModel("cartData").getProperty("/cartItem");
            let cartModel = {
                cartEmpty:false,
                cartItem:[]
            }

            if(Object.keys(cartItem).length==0){
                cartModel.cartEmpty=true
            }

            if(!cartModel.cartEmpty){
                var aProducts = this.getOwnerComponent().getModel("product").getProperty("/product");
                for(product of aProducts){
                    if(cartItem[product["ProductId"]]){
                        product.cartCount = cartItem[product["ProductId"]];
                        cartModel.cartItem.push(product);
                    }
                }
            }

            this.getView().setModel(new JSONModel(cartModel), "cartPageData");
            this.cartTable = this.getView().byId("cartTable");
        },

        onDug: function(){
            debugger;
        },

        onRemoveFromCart: function(oEvent){
            let remId = oEvent.getSource().data("prodId");
            let aProduct = this.cartTable.getModel("cartPageData").getProperty("/cartItem")
            for(let i = 0; i < aProduct.length; i++){
                if(aProduct[i].ProductId==remId){
                    this.cartTable.getModel("cartPageData").setProperty("/cartItem", aProduct.slice(0,i).concat(aProduct.slice(i+1, aProduct.length)));
                }
            }
        },

        onNavToProducts: function(){
            var oRouter = this.getOwnerComponent().getRouter();
            
            oRouter.navTo("main");
        }
    })

})