sap.ui.define([
    "sap/ui/core/mvc/Controller"
],function(Controller){
    return Controller.extend("wierd.controller.Main", {
        onInvertText: function(){
            var userText = this.getView().getModel().getProperty("/userInput");
            var words = userText.split(" ");
            for(var i in words){
                words[i] = words[i].split("").reverse().join("");
            }
            this.getView().getModel().setProperty("/invertedText", words.join(" "));
            MessageToast("Text Inverted. Press Ok to continue");
        }
    })
})