sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/resource/ResourceModel"
], function(UIComponent, JSONModel, ResourceModel){
    "use strict";

    return UIComponent.extend("wierd.Component",{
        metadata:{
            manifest:"json"
        },
        init: function(){
            UIComponent.prototype.init.apply(this, arguments);

            var helper = {
                userInput:"Enter your text here ...",
                invertedText:""
            }

            var helperModel = new JSONModel(helper);
            this.setModel(helperModel);

            
            var i18nModel = new ResourceModel({
                bundleName:"wierd.i18n.i18n"
            });
            
            this.setModel(i18nModel, "i18n");
        }
    })
})