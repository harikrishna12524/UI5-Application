function invertText(text){
    var words = text.split(" ");
    for(var i in words){
        words[i] = words[i].split("").reverse().join("");
    }
    alert(words);
}